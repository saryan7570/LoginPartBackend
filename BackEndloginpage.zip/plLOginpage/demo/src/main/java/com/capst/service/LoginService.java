package com.capst.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capst.dao.ICustomerDao;
import com.capst.dao.ILoginDao;
import com.capst.dao.IMerchantDao;
import com.capst.model.Customer;
import com.capst.model.Login;
import com.capst.model.Merchant;


@Service
public class LoginService implements ILoginService{

	@Autowired
	private ILoginDao loginDao;
	
	@Autowired
	private ICustomerDao customerDao;
	
	@Autowired
	private IMerchantDao merchantDao;
	
	@Override
	public Login getLogin(String emailId, String password) {
		Login login=loginDao.getByEmailIdAndPassword( emailId, password);
		System.out.println(login);
		return login;
	
	}

	@Override
	public Customer getCustLogin(String emailId, String password) {
		Customer customer=customerDao.getCustAcc(emailId,password); 
		System.out.println(customer);
		return customer;
	}

	@Override
	public Merchant getMerLogin(String emailId, String password) {
		Merchant merchant = merchantDao.getMerAcc(emailId, password);
		return merchant;
	}


	
}
