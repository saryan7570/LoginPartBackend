package com.capst.model;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="cap_Store_Customers")
public class Customer {

	@Id
	@Column(name="cap_store_customerId")
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int customerId;
	@Column(name="cap_store_CustfirstName")
	private String firstName;
	@Column(name="cap_store_CustlastName")
	private String lastName;
	@Column(name="cap_store_CustmobileNumber")
	private String mobileNumber;
	@Column(unique=true,name="cap_store_CustAccEmail")
	private String emailId;
	@Column(name="cap_store_CustAccPassword")
	private String password;
	
//	@OneToMany(targetEntity=Address.class,cascade=CascadeType.ALL)
//	private List<Address> addresses = new ArrayList<>();
	
	@Column(name="Cust_isVerified")
	private boolean isVerified;

public Customer(int customerId, String firstName, String lastName, String mobileNumber, String emailId, String password,
		boolean isVerified) {
	super();
	this.customerId = customerId;
	this.firstName = firstName;
	this.lastName = lastName;
	this.mobileNumber = mobileNumber;
	this.emailId = emailId;
	this.password = password;
	this.isVerified = isVerified;
}

public Customer() {
}

/**
 * @return the customerId
 */
public int getCustomerId() {
	return customerId;
}

/**
 * @param customerId the customerId to set
 */
public void setCustomerId(int customerId) {
	this.customerId = customerId;
}

/**
 * @return the firstName
 */
public String getFirstName() {
	return firstName;
}

/**
 * @param firstName the firstName to set
 */
public void setFirstName(String firstName) {
	this.firstName = firstName;
}

/**
 * @return the lastName
 */
public String getLastName() {
	return lastName;
}

/**
 * @param lastName the lastName to set
 */
public void setLastName(String lastName) {
	this.lastName = lastName;
}

/**
 * @return the mobileNumber
 */
public String getMobileNumber() {
	return mobileNumber;
}

/**
 * @param mobileNumber the mobileNumber to set
 */
public void setMobileNumber(String mobileNumber) {
	this.mobileNumber = mobileNumber;
}

/**
 * @return the emailId
 */
public String getEmailId() {
	return emailId;
}

/**
 * @param emailId the emailId to set
 */
public void setEmailId(String emailId) {
	this.emailId = emailId;
}

/**
 * @return the password
 */
public String getPassword() {
	return password;
}

/**
 * @param password the password to set
 */
public void setPassword(String password) {
	this.password = password;
}

/**
 * @return the isVerified
 */
public boolean isVerified() {
	return isVerified;
}

/**
 * @param isVerified the isVerified to set
 */
public void setVerified(boolean isVerified) {
	this.isVerified = isVerified;
}
	
	
	
}
