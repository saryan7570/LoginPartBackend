package com.capst.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capst.model.Login;

@Repository
public interface ILoginDao extends JpaRepository<Login, Integer> {
	/* @Query("from Login where emailId=:emailId and password=:password") */
	public Login getByEmailIdAndPassword(String emailId, String password);
	
	
	
}
