package com.capst.model;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="cap_store_Merchant")
public class Merchant {

	@Id
	@Column(name="cap_store_merchantId")
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int merchantId;
	@Column(name="cap_Merchant_mName")
	private String merchantName;
	
	@Column(unique=true,name="capMerchant_emailId")
	private String emailId;
	@Column(unique=true,name="capMerchant_password")
	private String merchantPassword;
	@Column(unique=true,name="capMerchant_contact")
	private String merchantContact;
	
//	@OneToOne(targetEntity=Address.class,cascade=CascadeType.ALL)
//	@Column(name="merchantAddress")
//	private Address merchantAddress;
	@Column(unique=true,name="capMerchant_verify")
	private boolean isVerified;

	
	
	
	
	public Merchant(int merchantId, String merchantName, String emailId, String merchantPassword, String merchantContact,
		boolean isVerified) {
	super();
	this.merchantId = merchantId;
	this.merchantName = merchantName;
	this.emailId = emailId;
	this.merchantPassword = merchantPassword;
	this.merchantContact = merchantContact;
	this.isVerified = isVerified;
}
	
	
	

	public Merchant() {
	
	}




	/**
	 * @return the merchantId
	 */
	public int getMerchantId() {
		return merchantId;
	}

	/**
	 * @param merchantId the merchantId to set
	 */
	public void setMerchantId(int merchantId) {
		this.merchantId = merchantId;
	}

	/**
	 * @return the merchantName
	 */
	public String getMerchantName() {
		return merchantName;
	}

	/**
	 * @param merchantName the merchantName to set
	 */
	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}

	/**
	 * @return the emailId
	 */
	public String getEmailId() {
		return emailId;
	}

	/**
	 * @param emailId the emailId to set
	 */
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	/**
	 * @return the merchantPassword
	 */
	public String getMerchantPassword() {
		return merchantPassword;
	}

	/**
	 * @param merchantPassword the merchantPassword to set
	 */
	public void setMerchantPassword(String merchantPassword) {
		this.merchantPassword = merchantPassword;
	}

	/**
	 * @return the merchantContact
	 */
	public String getMerchantContact() {
		return merchantContact;
	}

	/**
	 * @param merchantContact the merchantContact to set
	 */
	public void setMerchantContact(String merchantContact) {
		this.merchantContact = merchantContact;
	}

	/**
	 * @return the isVerified
	 */
	public boolean isVerified() {
		return isVerified;
	}

	/**
	 * @param isVerified the isVerified to set
	 */
	public void setVerified(boolean isVerified) {
		this.isVerified = isVerified;
	}




	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Merchant [merchantId=" + merchantId + ", merchantName=" + merchantName + ", emailId=" + emailId
				+ ", merchantPassword=" + merchantPassword + ", merchantContact=" + merchantContact + ", isVerified="
				+ isVerified + "]";
	}
	
	
	
}
