package com.capst.service;

import com.capst.model.Customer;
import com.capst.model.Login;
import com.capst.model.Merchant;

public interface ILoginService {
	
	public Login getLogin(String emailId, String password);
	public Customer getCustLogin(String emailId,String password);
	public Merchant getMerLogin(String emailId,String password);
	
}
