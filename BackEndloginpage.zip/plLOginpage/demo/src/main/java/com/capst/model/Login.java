package com.capst.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="CapStoreUser_Login")
public class Login {

	@Id
	@Column(name="serialNo")
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int serialNo;
	
	@Column(unique=true,name="Email_Id")
	private String emailId;
	@Column(name="Pass_word")
	private String password;
	private String userTypes;
	
	
	
	
	public Login(int serialNo, String emailId, String password, String userTypes) {
		super();
		this.serialNo = serialNo;
		this.emailId = emailId;
		this.password = password;
		this.userTypes = userTypes;
	}
	
	
	
	public Login() {
	}



	/**
	 * @return the serialNo
	 */
	public int getSerialNo() {
		return serialNo;
	}
	/**
	 * @param serialNo the serialNo to set
	 */
	public void setSerialNo(int serialNo) {
		this.serialNo = serialNo;
	}
	/**
	 * @return the emailId
	 */
	public String getEmailId() {
		return emailId;
	}
	/**
	 * @param emailId the emailId to set
	 */
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}
	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}
	/**
	 * @return the userTypes
	 */
	public String getUserTypes() {
		return userTypes;
	}
	/**
	 * @param userTypes the userTypes to set
	 */
	public void setUserTypes(String userTypes) {
		this.userTypes = userTypes;
	}



	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Login [serialNo=" + serialNo + ", emailId=" + emailId + ", password=" + password + ", userTypes="
				+ userTypes + "]";
	}
	
	
	
	
}
