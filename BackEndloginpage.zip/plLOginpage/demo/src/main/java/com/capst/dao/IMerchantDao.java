package com.capst.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.capst.model.Merchant;

public interface IMerchantDao extends JpaRepository<Merchant, Integer> {

	@Query("from Merchant where emailId=:emailId and merchantPassword=:password")
	public Merchant getMerAcc(String emailId,String password);
	
}
