package com.capst.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.capst.model.Customer;
@Repository
public interface ICustomerDao extends JpaRepository<Customer,Integer> {

	
	@Query("from Customer where emailId=:emailId and password=:password")
	public Customer getCustAcc(String customerEmail,String cutomerPassword);
	
	
}
